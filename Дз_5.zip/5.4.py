rus = {'One' : 'Один', 'Two' : 'Два', 'Three' : 'Три', 'Four' : 'Четыре'}
new_file = []
with open('Chislet.txt', 'r') as f:
    #content = file_obj.read().split('\n')
    # for i in file_obj:
    i = f.readline()
    while i:
        i = i.split(' ', 1)
        new_file.append(rus[i[0]] + ' ' + i[1])
        i = f.readline()
        i = f.readline()

with open('Chislet_novaya.txt', 'w') as f:
    f.writelines(new_file)