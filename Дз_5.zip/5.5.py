f = open("Chisla.txt", 'w')
s = f.writelines("5 10 15 20 25 25")
f.close()
with open('Chisla.txt', 'r') as f:
    sum_ch = 0
    s = f.readline()
    while s:
        sum_ch += float(s[:s.find(" ")])
        s = s[s.find(" ") + 1:]
        if s.find(" ") == -1:
            break
print(sum_ch + float(s))