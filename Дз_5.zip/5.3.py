f = open("Sotrud.txt", 'r')
# k_str = 0
# k_slov = 0
s = f.readline()
oklad = int(s[s.find(" "):])
sr = 0
k_sot = 0
print(oklad)

while s:
    k_sot += 1
    oklad = int(s[s.find(" "):])
    sr += oklad
    if oklad < 20000:
        print(s[:s.find(" ")])
    s = f.readline()
print(f"Sredni oklad sotrudnikov {sr/k_sot} strok")
f.close()