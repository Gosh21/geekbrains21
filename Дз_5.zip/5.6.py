subj = {}
with open('Predmeti.txt', 'r') as f:
    for line in f:
        subject, lecture, practice, lab = line.split()
        if lecture == '—':
            lecture = 0
        else:
            lecture = lecture[:(lecture.find("("))]
        if practice == '—':
            practice = 0
        else:
            practice = practice[:(practice.find("("))]
        if lab == '—':
            lab = 0
        else:
            lab = lab[:(lab.find("("))]
        subj[subject] = int(lecture) + int(practice) + int(lab)
    print(f'Всего часов по предмету - \n {subj}')