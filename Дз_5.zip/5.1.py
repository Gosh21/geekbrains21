f = open("my_file.txt", 'w')
s = "qwwe"
while s != "":
    s = input(str("Vvedite nadpis: "))
    f.writelines(s + "\n")

f.close()