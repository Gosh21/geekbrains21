f = open("my_file.txt", 'r')
k_str = 0
k_slov = 0
s = f.readline()
print(type(s))
while s:
    k_str += 1
    k_slov += len((s.split()))
    print(f"V {k_str} stroke kol-vo slov = {k_slov}")
    k_slov = 0
    s = f.readline()
print(f"V faile vsego {k_str} strok")
f.close()