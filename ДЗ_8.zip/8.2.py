class DelNaNol:
    # def __init__(self, delim, delit):
    #     self.delim = delim
    #     self.delit = delit

    @staticmethod
    def Proverka(delim, delit):
        if delit != 0:
            return (delim / delit)
        else:
            return (f"Деление на ноль недопустимо")


div = DelNaNol()
print(div.Proverka(102, 100))
print(div.Proverka(123, 0))
print(div.Proverka(0, 999))