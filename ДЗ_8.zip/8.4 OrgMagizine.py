class sklad:
    def __init__(self):
        self._dict = {}

    def add_to(self, equipment):
        self._dict.setdefault(equipment.group_name(), []).append(equipment) #добавления в словарь ключ с названием класса орг. техники
                                                                            # и пустого списка,  в который в последствии будем
                                                                            # заполнять харасктеристику элементов

    def extract(self, name):
        ''' извлекаем из значения обьект по названию группы.
        дальше можно расширить поиск по серии, марки или еще чему либо'''
        if self._dict[name]:
            self._dict.setdefault(name).pop(0)


class OrgTexnika:
    def __init__(self, name, price, quantity):
        self.name = name
        self.price = price
        self.quantity = quantity
        self.group = self.__class__.__name__  # получение имени класса


    def group_name(self):
        return f'{self.group}'

    def __repr__(self):
        return f'{self.name} {self.price} {self.quantity}'



class Printer(OrgTexnika):
    def __init__(self, name, price, quantity, tip_pechat):
        # self.name = name
        # self.price = price
        # self.quantity = quantity
        super().__init__(name, price, quantity)
        self.tip_pechat = tip_pechat

    def __repr__(self):
        return f'{self.name} {self.price} {self.quantity} {self.tip_pechat}'


    def to_print(self):
        return f'to print smth {self.name} times'


class Scanner(OrgTexnika):
    def __init__(self, name, price, quantity, cvet_pechat):
        super().__init__(name, price, quantity)
        self.cvet_pechat = cvet_pechat

    def to_scan(self):
        return f'to scan smth {self.name} times'

    def __repr__(self):
        return f'{self.name} {self.price} {self.quantity} {self.cvet_pechat}'


class Copier(OrgTexnika):
    def __init__(self, name, price, quantity, skorost_pechat):
        super().__init__(name, price, quantity)
        self.skorost_pechat = skorost_pechat

    def to_copier(self):
        return f'to copier smth {self.name} times'

    def __repr__(self):
        return f'{self.name} {self.price} {self.quantity} {self.skorost_pechat}'


# создаем Склад
sklad = sklad()
# создаем объект и добавляем
scaner = Scanner('hp', 2000, 10, 'cvet')
sklad.add_to(scaner)
print(scaner.to_scan())
prin = Printer('GHbynht', 5000, 12, 'Lazer')
sklad.add_to(prin)
print(prin.to_print())
cop = Copier('VHGGVV', 10000, 15, 25)
sklad.add_to(cop)
print(cop.to_copier())
scaner2 = Scanner('hp2', 2000, 10, 'cvet')
sklad.add_to(scaner2)
print(scaner2.to_scan())


print(sklad._dict)