
class data():

    def __init__(self, dat):
        self.dat = dat

    @classmethod
    def preobr(cls, dat):
        ch = int(dat[ :dat.find('-')])
        mes = int(dat[ dat.find('-') + 1:dat.rfind('-')])
        god = int (dat[dat.rfind('-') + 1:])
        # print('djj xbckj:::  ', ch, '  jgjhh   ', mes, '  god  ', god)
        return ch, mes, god

    @staticmethod
    def valid(day, month, year):

        if 1 <= day <= 31:
            if 1 <= month <= 12:
                if 2021 >= year >= 0:
                    return f'Все верно'
                else:
                    return f'Неправильный год'
            else:
                return f'Неправильный месяц'
        else:
            return f'Неправильный день'



d = data('18-09-1999')
d.preobr('18-09-1999')
print(d.preobr('18-09-1999'))
print(data.preobr('22-12-2021'))
print(data.valid(18, 10, 2021 ))
print(d.valid(11, 13, 2011))