class OwnError():
    # def __init__(self, txt):
    #     self.txt = txt
    #     print('dfsdf   ', txt)

    inp_data = input("Введите число: ")
    data = []
    # print(inp_data.isdigit())
    while inp_data != 'stop':
        if not inp_data.isdigit():
            print ("Oshibka! Vvedite chislo ")
        else:
            data.append(float(inp_data))
        inp_data = input("Введите число: ")





# try:
#     inp_data = int(inp_data)
#     if inp_data < 0:
#         raise OwnError("Вы ввели отрицательное число!")
# except ValueError:
#     print("Вы ввели не число")
# except OwnError as err:
#     print(err)
# else:
#     print(f"Все хорошо. Ваше число: {inp_data}")

