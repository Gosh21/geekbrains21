class Road:
    def __init__(self, _length, _width, _mass):
         self._length = _length
         self._width = _width
         self._mass = _mass

    def mass(self):
        return self._length * self._width * self._mass



r = Road(int(input("Dlina = ")), int(input("Shirina = ")), int(input("Mass = ")))
print(r.mass())