
class Car:
    # atributes
    def __init__(self, speed, color, name, is_police):
        self.speed = speed
        self.color = color
        self.name = name
        self.is_police = is_police
    # methods
    def go(self):
        return f'{self.name} nachal dvijenie'

    def stop(self):
        return f'{self.name} ostanovilsya'

    def turn_right(self):
        # if self.name == "right":
        return f'{self.name} повернула на право'
        # else:
        #     return f'{self.name} is turned left'
    def turn_left(self):
        # if self.name == "right":
        return f'{self.name} повернула на лево'


    def show_speed(self):
        return f'Skorost {self.name} ravna {self.speed}'

class TownCar(Car):
    def __init__(self, speed, color, name, is_police):
        super().__init__(speed, color, name, is_police)
    def show_speed(self):
        if self.speed > 40:
            return f'Скорость {self.name} выше нормы.'
        else:
            return f'Скорость {self.name} в норме.'


class SportCar(Car):
    def __init__(self, speed, color, name, is_police):
        super().__init__(speed, color, name, is_police)


class WorkCar(Car):
    def __init__(self, speed, color, name, is_police):
        super().__init__(speed, color, name, is_police)

    def show_speed(self):
        if self.speed > 60:
            return f'Скорость {self.name} выше нормы.'
        else:
            return f'Скорость {self.name} в норме.'


class PoliceCar(Car):
    def __init__(self, speed, color, name, is_police):
        super().__init__(speed, color, name, is_police)

t = TownCar(60, "Ptktys", "Fhdgjhs", True)
print(t.show_speed())
print(t.turn_right())
s = SportCar(100, 'Korich', "Molniya", False)
print(s.show_speed())
print(s.turn_right())
w = WorkCar(60, "Zel", "Job", False)
print(w.show_speed())
print(w.turn_left())
p = PoliceCar(130, "sinie", "Policiy", True)
print(p.show_speed())
print(p.turn_left())
print(p.turn_right())

