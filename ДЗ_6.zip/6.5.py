class Stationery:
    def __init__(self, title):
        self.title = title

    def draw(self):
        print('Запуск отрисовки.')

class Pen(Stationery):
    def __init__(self, title):
        super().__init__(title)

    def draw(self):
        return f'Отрисовка {self.title} Pen.'


class Pencil(Stationery):
    def __init__(self, title):
        super().__init__(title)

    def draw(self):
        return f'Отрисовка {self.title} Pencil.'


class Handle(Stationery):
    def __init__(self, title):
        super().__init__(title)

    def draw(self):
        return f'Отрисовка {self.title} Handle.'



p = Pen("ASDFGHjkl")
print(p.draw())

pe = Pencil("QWERTY")
print(pe.draw())

h = Handle("Zxcvbnm,/.,mnbvcx")
print(h.draw())

