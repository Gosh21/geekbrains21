from time import sleep

class TrafficLight:
    __color = ["Красный", "Желтый", "Зеленый"]
    def running ():
        print("Eto metod running ")
        i = 0
        while i < 3:
            print(f'Светофор переключается на: {TrafficLight.__color[i]}')
            if i == 0:
                sleep(7)
            elif i == 1:
                sleep(2)
            elif i == 2:
                sleep(10)
            i += 1


t = TrafficLight
t.running()