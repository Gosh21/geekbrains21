class Matrix:
    def __init__(self, mat):
        self.mat = mat

    def __add__(self, other):
        matr = []

        for i in range(len(m1.mat)):
            matr.append([])
            for j in range(len(m2.mat[i])):
                matr[i].append(m1.mat[i][j] + m2.mat[i][j])
        return Matrix(matr)

    def __str__(self):
        return str('\n'.join([('\t'.join(str(j) for j in i)) for i in self.mat]))

m1 = Matrix([[1, 2, 3], [1, 2, 3], [5, 6, 7]])
m2 = Matrix([[-1, -2, -3], [-1, -2, -3], [100, 200, 300]])
print(m1 + m2)
