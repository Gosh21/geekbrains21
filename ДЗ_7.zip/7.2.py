class Textil:
    def __init__(self, w, h):
        self.w = float(w)
        self.h = float(h)

    def s_c(self):
        return self.w / 6.5 + 0.5

    def s_j(self):
        return self.h * 2 + 0.3

    @property
    def s_o(self):
        print(self.w)
        # print(other)
        return str(f'Площадь общая ткани '
                   f' {(self.w / 6.5 + 0.5) + (self.h * 2 + 0.3)}')


class Coat(Textil):
    def __init__(self, width, height):
        super().__init__(width, height)
        self.ss_c = float((self.w / 6.5) + 0.5)
        # return (self.s_c)
    def __str__(self):
        return f'Площадь на пальто {self.ss_c}'



class Jacket(Textil):
    def __init__(self, width, height):
        super().__init__(width, height)
        self.ss_j = float(self.h * 2 + 0.3)

    def __str__(self):
        return f'Площадь на костюм {self.ss_j}'


c = Coat(2, 4)
j = Jacket(1, 2)
print(c)
print(j)
print("Общая площадь ткани для производства одежды: %.2f" %(c.s_c() + j.s_j()))
print(c.s_c())
print(j.s_j())
print(c.s_o)