class kletka:
    def __init__(self, kol_vo):
        self.kol_vo = float(kol_vo)

    def __str__(self):
        if(self.kol_vo) > 0:
            return f'Kolichestvo kletok ravna: {self.kol_vo}'
        else:
            print('Отрицательное значение!')

    def __add__(self, other):
        return kletka(self.kol_vo + other.kol_vo)

    def __sub__(self, other):
        return kletka(self.kol_vo - other.kol_vo) if (self.kol_vo - other.kol_vo) > 0 else print('Отрицательное значение!')

    def __mul__(self, other):
        return kletka(int(self.kol_vo * other.kol_vo))

    def __truediv__(self, other):
        return kletka(round(self.kol_vo / other.kol_vo))

    def mo(self, ryad):
        row = ''
        for i in range(int(self.kol_vo / ryad)):
            row += f'{"*" * ryad} \n'
        row += f'{"*" * (int(self.kol_vo) % ryad)}'
        return row


k1 = kletka (18)
k2 = kletka (5)
print(k1 + k2)
print(k1 - k2)
print(k1 / k2)
print(k1 * k2)
print(k1.mo(5))