#Не много ни понял условие задачи, поэтому посчитал что убыток
#это тоже прибыль, только с отрицательным знаком (это где нужно ввести число сотрудников)
v = float (input("Viruchka:  "))
i = float (input("Izderjki:  "))

if (v - i) > 0 :
    print("Firma rabotaet v pribil  ")
    print("Rentabelnost firmi:  ", (v-i)/v)
elif (v - i) < 0 :
    print("Firma rabotaet v ubitok  ")
else:
    print("Firma rabotaet v noll  ")

s = int (input("Kolichestvo sotrudnikov:  "))
print("Rentabelnost firmi:  ", (v-i)/s)