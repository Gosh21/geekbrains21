s = int (input())
h = s // 3600
m = (s - h*3600) // 60
s -= (h*3600 + m*60)
print("%02d:%02d:%02d" %(h, m, s))