i = 5**5
print ("Integer variable: ", i)
f = 123.456
print ("Float variable: ", f)
s = 'I love GeekBrains'
print("String variable: ", s)
b = True
print("Boolean variable: ", b)



i = int (input("Vvedite celoe chislo: "))
print ("Vashe chislo: %d" %(i))

f = float (input("Vvedite NE celoe chislo: "))
print (f"Vashe chislo: {f}")

s = input("Vvedite stroku: ")
print (f"Vasha stroka: {s}")