a = float (input())
b = float (input())
nomer_dnya = 1

print(f"{nomer_dnya}-й день: {round(a,2)} ")

while a < b :
    a *= 1.1
    nomer_dnya += 1
    print(f"{nomer_dnya}-й день: {round(a, 2)} ")
print(f"На {nomer_dnya}-й день спортсмен достиг результата - не менее {round(a, 2)} ")