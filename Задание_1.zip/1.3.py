n = int (input())
i=n
s = 0

while i != 0:
    i //= 10
    s += 1

nn = n * (10**s) + n
nnn = n * ((10**s)**2) + nn

print (f"{n} + {nn} + {nnn} = ", n + nn + nnn)